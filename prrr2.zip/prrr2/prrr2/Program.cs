﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace MyApp
{
    internal class Program
    {
        private static string TTyTb = @"C:\files";

        static void Main()
        {
            // файл из папки
            string[] files = Directory.GetFiles(TTyTb);

            foreach (var file in files)
            {
                // Синхронность
                Sin(file);

                // Асинхронность
                Asin(file).GetAwaiter().GetResult();

                // Поток
                Potok(file);
            }

        }
        public static void Sin(string files)
        {
            Stopwatch sw = Stopwatch.StartNew();
            long kolvosim = 0;
            for (int i = 0; i < 5; i++)
            {
                string text = File.ReadAllText(files);
                kolvosim += text.Length;
            }
            sw.Stop();
            Console.WriteLine($"Количество символов: {kolvosim}");
            Console.WriteLine($"Время синхронности за: {sw.ElapsedMilliseconds}\n");
        }
        public static async Task Asin(string file)
        {
            Stopwatch sw = Stopwatch.StartNew();
            long kolvosim = 0;
            var tasks = new Task<int>[5];

            for (int i = 0; i < 5; i++)
            {
                tasks[i] = Task.Run(() =>
                {
                    string text = File.ReadAllText(file);
                    return text.Length;
                });
            }
            int[] dlina = await Task.WhenAll(tasks);
            kolvosim = dlina.Sum(x => (long)x);
            sw.Stop();
            Console.WriteLine($"Количество символов: {kolvosim}");
            Console.WriteLine($"Время асинхронности за: {sw.ElapsedMilliseconds}\n");
        }
        public static void Potok(string files)
        {
            Stopwatch sw = Stopwatch.StartNew();
            long kolvosim = 0;

            Thread[] threads = new Thread[5];

            for (int i = 0; i < 5; i++)
            {
                threads[i] = new Thread(() =>
                {
                    string text = File.ReadAllText(files);
                    Interlocked.Add(ref kolvosim, text.Length); 
                });
                threads[i].Start();
            }

            foreach (var thread in threads)
            {
                thread.Join();
            }
            sw.Stop();
            Console.WriteLine($"Количество символов: {kolvosim}");
            Console.WriteLine($"Время потока за: {sw.ElapsedMilliseconds}\n");
        }
    }
}